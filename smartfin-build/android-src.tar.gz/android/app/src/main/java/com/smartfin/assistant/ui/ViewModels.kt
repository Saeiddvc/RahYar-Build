package com.smartfin.assistant.ui
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.smartfin.assistant.data.model.*
import com.smartfin.assistant.data.repository.FinanceRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
data class AuthState(val loading:Boolean=false,val loggedIn:Boolean=false,val error:String?=null)
class AuthViewModel(private val r:FinanceRepository):ViewModel(){ val state=MutableStateFlow(AuthState()); init{viewModelScope.launch{state.value=state.value.copy(loggedIn=r.hasToken())}}; fun login(e:String,p:String)=go{r.login(e,p)}; fun register(n:String,e:String,p:String)=go{r.register(n,e,p)}; private fun go(block:suspend()->Unit)=viewModelScope.launch{state.value=AuthState(true); runCatching{block()}.onSuccess{state.value=AuthState(loggedIn=true)}.onFailure{state.value=AuthState(error=it.message?:"خطا")}}; fun logout()=viewModelScope.launch{r.logout();state.value=AuthState()} }
data class FinanceState(val loading:Boolean=false,val user:UserDto?=null,val transactions:List<TransactionDto> = emptyList(),val incomes:List<IncomeDto> = emptyList(),val goals:List<GoalDto> = emptyList(),val recommendations:List<RecommendationDto> = emptyList(),val behavior:BehaviorDto?=null,val forecast:ForecastDto?=null,val risk:RiskDto?=null,val error:String?=null)
class FinanceViewModel(private val r:FinanceRepository):ViewModel(){ val state=MutableStateFlow(FinanceState()); fun refresh()=viewModelScope.launch{state.value=state.value.copy(loading=true,error=null); runCatching{FinanceState(user=r.me(),transactions=r.tx(),incomes=r.incomes(),goals=r.goals(),recommendations=r.recommendations(),behavior=r.behavior(),forecast=r.forecast(),risk=r.risk())}.onSuccess{state.value=it}.onFailure{state.value=state.value.copy(loading=false,error=it.message)}}; fun addTx(x:TransactionDto)=act{r.addTx(x)};fun delTx(id:Int)=act{r.delTx(id)};fun addIncome(x:IncomeDto)=act{r.addIncome(x)};fun delIncome(id:Int)=act{r.delIncome(id)};fun addGoal(x:GoalDto)=act{r.addGoal(x)};fun delGoal(id:Int)=act{r.delGoal(id)};fun calculateRisk(a:RiskAnswers)=act{r.calcRisk(a)};private fun act(b:suspend()->Unit)=viewModelScope.launch{runCatching{b()}.onFailure{state.value=state.value.copy(error=it.message)};refresh()} }
data class ChatMessage(val mine:Boolean,val text:String); data class ChatState(val loading:Boolean=false,val messages:List<ChatMessage> = listOf(ChatMessage(false,"سلام. درباره وضعیت مالی، کاهش هزینه یا برنامه رسیدن به هدف سؤال کنید.")),val error:String?=null)
class ChatViewModel(private val r:FinanceRepository):ViewModel(){val state=MutableStateFlow(ChatState());fun send(m:String){if(m.isBlank())return;viewModelScope.launch{state.value=state.value.copy(loading=true,messages=state.value.messages+ChatMessage(true,m));runCatching{r.chat(m)}.onSuccess{state.value=state.value.copy(loading=false,messages=state.value.messages+ChatMessage(false,it.answer))}.onFailure{state.value=state.value.copy(loading=false,error=it.message)}}}}

data class InvestmentState(
    val loading:Boolean=false,
    val capital:String="100000",
    val horizonMonths:Int=6,
    val riskLevel:String="medium",
    val portfolio:PortfolioResponse?=null,
    val simulation:SimulationResponse?=null,
    val institutions:List<InstitutionDto> = emptyList(),
    val recommendedInstitutions:Map<String,InstitutionDto> = emptyMap(),
    val disclaimer:String?=null,
    val error:String?=null
)
class InvestmentViewModel(private val r:FinanceRepository):ViewModel(){
    val state=MutableStateFlow(InvestmentState())
    fun setCapital(v:String){state.value=state.value.copy(capital=v)}
    fun setHorizon(v:Int){state.value=state.value.copy(horizonMonths=v)}
    fun setRisk(v:String){state.value=state.value.copy(riskLevel=v)}
    fun loadInstitutions()=viewModelScope.launch{runCatching{r.institutions()}.onSuccess{state.value=state.value.copy(institutions=it)}.onFailure{state.value=state.value.copy(error=it.message)}}
    fun suggest()=viewModelScope.launch{
        val c=state.value.capital.toDoubleOrNull()?:return@launch
        state.value=state.value.copy(loading=true,error=null)
        runCatching{r.investmentRecommendation(PortfolioSuggestRequest(c,state.value.horizonMonths,state.value.riskLevel))}
            .onSuccess{state.value=state.value.copy(loading=false,portfolio=it.allocation,simulation=it.simulation,recommendedInstitutions=it.institutions,disclaimer=it.disclaimer)}
            .onFailure{state.value=state.value.copy(loading=false,error=it.message)}
    }
    fun simulate()=viewModelScope.launch{
        val c=state.value.capital.toDoubleOrNull()?:return@launch
        val a=state.value.portfolio?.allocation?:return@launch
        val req=SimulationRequest(c,state.value.horizonMonths,AllocationRequest(a["bank_deposit"]?:0.0,a["fixed_income_fund"]?:0.0,a["mixed_fund"]?:0.0,a["equities"]?:0.0,a["gold"]?:0.0))
        state.value=state.value.copy(loading=true,error=null)
        runCatching{r.simulate(req)}.onSuccess{state.value=state.value.copy(loading=false,simulation=it)}.onFailure{state.value=state.value.copy(loading=false,error=it.message)}
    }
}
