package com.smartfin.assistant.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.smartfin.assistant.data.model.InstitutionDto
import com.smartfin.assistant.ui.InvestmentViewModel
import com.smartfin.assistant.ui.components.money
import kotlin.math.roundToInt

private val assetLabels=mapOf(
    "bank_deposit" to "سپرده بانکی",
    "fixed_income_fund" to "صندوق درآمد ثابت",
    "mixed_fund" to "صندوق مختلط",
    "equities" to "سهام",
    "gold" to "طلا"
)
private val pieColors=listOf(Color(0xFF175D5A),Color(0xFF279C8F),Color(0xFF74C5B9),Color(0xFFE3A34D),Color(0xFFC76D55))

@Composable fun InvestmentHubScreen(vm:InvestmentViewModel){
    val s by vm.state.collectAsState();var tab by remember{mutableIntStateOf(0)}
    LaunchedEffect(Unit){vm.loadInstitutions()}
    Column(Modifier.fillMaxSize()){
        Text("سرمایه‌گذاری هوشمند",style=MaterialTheme.typography.headlineSmall,modifier=Modifier.padding(16.dp))
        TabRow(selectedTabIndex=tab){listOf("پیشنهاد","شبیه‌سازی","نهادها").forEachIndexed{i,t->Tab(tab==i,{tab=i},text={Text(t)})}}
        when(tab){0->SuggestionTab(vm);1->SimulationTab(vm);else->InstitutionsTab(s.institutions)}
    }
}

@Composable private fun SuggestionTab(vm:InvestmentViewModel){val s by vm.state.collectAsState();LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
    item{OutlinedTextField(s.capital,vm::setCapital,label={Text("سرمایه قابل تخصیص")},modifier=Modifier.fillMaxWidth())}
    item{Text("افق زمانی");SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()){listOf(3,6,12).forEachIndexed{i,m->SegmentedButton(selected=s.horizonMonths==m,onClick={vm.setHorizon(m)},shape=SegmentedButtonDefaults.itemShape(i,3)){Text("$m ماه")}}}}
    item{Text("سطح ریسک");SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()){listOf("low","medium","high").forEachIndexed{i,r->SegmentedButton(selected=s.riskLevel==r,onClick={vm.setRisk(r)},shape=SegmentedButtonDefaults.itemShape(i,3)){Text(when(r){"low"->"کم";"high"->"زیاد";else->"متوسط"})}}}}
    item{Button(vm::suggest,Modifier.fillMaxWidth(),enabled=!s.loading){Text(if(s.loading)"در حال محاسبه…" else "محاسبه پیشنهاد")};s.error?.let{Text(it,color=MaterialTheme.colorScheme.error)}}
    s.portfolio?.let{p->item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("ترکیب پیشنهادی",style=MaterialTheme.typography.titleMedium);AllocationPie(p.allocation);p.allocation.forEach{(k,v)->Text("${assetLabels[k]?:k}: ${(v*100).roundToInt()}٪")};Text("بازده سالانه مدل‌شده: ${(p.expected_annual_return*100).format1()}٪");Text("نوسان سالانه مدل‌شده: ${(p.estimated_annual_volatility*100).format1()}٪");p.rationale.forEach{Text("• $it")}}}}}
    if(s.recommendedInstitutions.isNotEmpty()) item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("نهادهای پیشنهادی",style=MaterialTheme.typography.titleMedium);s.recommendedInstitutions.forEach{(asset,x)->Text("${assetLabels[asset]?:asset}: ${x.name} • کارمزد ${(x.fee_rate*100).format2()}٪")}}}}
    s.disclaimer?.let{d->item{Text(d,style=MaterialTheme.typography.bodySmall)}}
}}

@Composable private fun SimulationTab(vm:InvestmentViewModel){val s by vm.state.collectAsState();LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
    item{Text("شبیه‌سازی سرمایه",style=MaterialTheme.typography.titleMedium);Text("ابتدا در تب پیشنهاد، ترکیب سرمایه را محاسبه کنید. سپس می‌توانید دوره را تغییر دهید و شبیه‌سازی مجدد بگیرید.")}
    item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf(3,6,12).forEach{m->FilterChip(selected=s.horizonMonths==m,onClick={vm.setHorizon(m)},label={Text("$m ماه")})}}}
    item{Button(vm::simulate,enabled=s.portfolio!=null&&!s.loading,modifier=Modifier.fillMaxWidth()){Text("اجرای شبیه‌سازی")}}
    s.simulation?.let{x->
        item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("Monte Carlo (${x.monte_carlo.simulations} اجرا)",style=MaterialTheme.typography.titleMedium);Text("صدک ۵٪: ${money(x.monte_carlo.p05)}");Text("میانه: ${money(x.monte_carlo.median)}");Text("صدک ۹۵٪: ${money(x.monte_carlo.p95)}");Text("احتمال زیان: ${(x.risk_metrics.probability_of_loss*100).format1()}٪");Text("VaR 95%: ${money(x.risk_metrics.value_at_risk_95)}")}}}
        x.scenarios.forEach{(name,sc)->item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(when(name){"conservative"->"سناریوی محافظه‌کارانه";"aggressive"->"سناریوی تهاجمی";else->"سناریوی متوسط"},style=MaterialTheme.typography.titleSmall);Text("ارزش پایان دوره: ${money(sc.total_future_value)}");Text("سود/زیان: ${money(sc.total_profit_loss)} (${sc.return_pct.format1()}٪)");sc.components.forEach{(k,c)->Text("${assetLabels[k]?:k}: ${money(c.future_value)}")}}}}}
    }
}}

@Composable private fun InstitutionsTab(list:List<InstitutionDto>){LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){if(list.isEmpty())item{Text("داده نهادها هنوز دریافت نشده است.")};items(list){x->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(x.name,style=MaterialTheme.typography.titleMedium);Text("${x.institution_type} • ${x.service_type}");Text("کارمزد تقریبی: ${(x.fee_rate*100).format2()}٪ • نقدشوندگی: ${x.liquidity_days} روز");Text("حداقل سرمایه: ${money(x.min_investment)} • ریسک: ${x.risk_level}")}}}}}

@Composable private fun AllocationPie(a:Map<String,Double>){Canvas(Modifier.size(180.dp).padding(8.dp)){var start=-90f;assetLabels.keys.forEachIndexed{i,k->val sweep=((a[k]?:0.0)*360).toFloat();drawArc(pieColors[i%pieColors.size],start,sweep,true);start+=sweep}}}
private fun Double.format1()="%.1f".format(this)
private fun Double.format2()="%.2f".format(this)
