package com.smartfin.assistant.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.smartfin.assistant.ui.AuthViewModel
@Composable fun SettingsScreen(vm:AuthViewModel){var currency by remember{mutableStateOf("IRR")};var lang by remember{mutableStateOf("fa")};Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("تنظیمات",style=MaterialTheme.typography.headlineSmall);OutlinedTextField(currency,{currency=it},label={Text("واحد پول")},modifier=Modifier.fillMaxWidth());OutlinedTextField(lang,{lang=it},label={Text("زبان")},modifier=Modifier.fillMaxWidth());Text("تنظیمات محلی در نسخه نمونه در حافظه صفحه نگهداری می‌شود؛ منبع اصلی پول هر رکورد در Backend ذخیره می‌شود.");OutlinedButton({vm.logout()},Modifier.fillMaxWidth()){Text("خروج از حساب")}}}
