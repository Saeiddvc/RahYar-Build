package com.smartfin.assistant.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
private val scheme=lightColorScheme(primary=Color(0xFF0B6B5E),secondary=Color(0xFF314D64),tertiary=Color(0xFFE07A5F),background=Color(0xFFF6F7F9),surface=Color.White)
@Composable fun SmartFinTheme(content:@Composable()->Unit){MaterialTheme(colorScheme=scheme,typography=Typography(),content=content)}
