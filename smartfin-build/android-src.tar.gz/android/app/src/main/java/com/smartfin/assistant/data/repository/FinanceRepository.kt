package com.smartfin.assistant.data.repository
import com.smartfin.assistant.auth.TokenStore
import com.smartfin.assistant.data.api.ApiService
import com.smartfin.assistant.data.model.*
class FinanceRepository(private val api:ApiService,private val tokens:TokenStore){
 suspend fun hasToken()=!tokens.get().isNullOrBlank()
 suspend fun register(n:String,e:String,p:String){val r=api.register(RegisterRequest(n,e,p));tokens.set(r.access_token)}
 suspend fun login(e:String,p:String){val r=api.login(LoginRequest(e,p));tokens.set(r.access_token)}
 suspend fun logout()=tokens.clear()
 suspend fun me()=api.me(); suspend fun tx()=api.transactions(); suspend fun addTx(x:TransactionDto)=api.addTransaction(x); suspend fun delTx(id:Int)=api.deleteTransaction(id)
 suspend fun incomes()=api.incomes(); suspend fun addIncome(x:IncomeDto)=api.addIncome(x); suspend fun delIncome(id:Int)=api.deleteIncome(id)
 suspend fun goals()=api.goals(); suspend fun addGoal(x:GoalDto)=api.addGoal(x); suspend fun delGoal(id:Int)=api.deleteGoal(id)
 suspend fun behavior()=api.behavior(); suspend fun forecast()=api.forecast(); suspend fun risk()=api.risk(); suspend fun calcRisk(a:RiskAnswers)=api.calculateRisk(a); suspend fun recommendations()=api.recommendations(); suspend fun chat(m:String)=api.chat(ChatRequest(m))
 suspend fun institutions()=api.institutions()
 suspend fun suggestPortfolio(x:PortfolioSuggestRequest)=api.suggestPortfolio(x)
 suspend fun simulate(x:SimulationRequest)=api.simulateInvestment(x)
 suspend fun investmentRecommendation(x:PortfolioSuggestRequest)=api.investmentRecommendation(x)
}
