package com.smartfin.assistant

import android.app.Application
import com.smartfin.assistant.di.appModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class SmartFinApp: Application() {
    override fun onCreate() { super.onCreate(); startKoin { androidContext(this@SmartFinApp); modules(appModule) } }
}
