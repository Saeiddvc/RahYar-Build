package com.smartfin.assistant.ui.components
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
@Composable fun StatCard(title:String,value:String,modifier:Modifier=Modifier){Card(modifier){Column(Modifier.padding(16.dp)){Text(title,style=MaterialTheme.typography.labelMedium);Spacer(Modifier.height(8.dp));Text(value,style=MaterialTheme.typography.titleLarge)}}}
@Composable fun ErrorText(s:String?){if(!s.isNullOrBlank()) Text(s,color=MaterialTheme.colorScheme.error,style=MaterialTheme.typography.bodySmall)}
fun money(v:Double)=String.format("%,.0f",v)
