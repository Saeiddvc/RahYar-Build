package com.smartfin.assistant.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.smartfin.assistant.data.model.RiskAnswers
import com.smartfin.assistant.ui.FinanceViewModel
import com.smartfin.assistant.ui.components.money
@Composable fun InsightsScreen(vm:FinanceViewModel){val s by vm.state.collectAsState();LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("AI Insights",style=MaterialTheme.typography.headlineSmall)};item{Card{Column(Modifier.padding(16.dp)){Text("رفتار مالی",style=MaterialTheme.typography.titleMedium);Text("تیپ: ${s.behavior?.behavior_type?:"نامشخص"}");Text("نسبت هزینه به درآمد: ${((s.behavior?.spending_to_income_ratio?:0.0)*100).toInt()}٪");Text("نرخ پس‌انداز: ${((s.behavior?.saving_ratio?:0.0)*100).toInt()}٪")}}};item{Card{Column(Modifier.padding(16.dp)){Text("پروفایل ریسک",style=MaterialTheme.typography.titleMedium);Text("سطح: ${s.risk?.risk_level?:"نامشخص"}");Text("امتیاز: ${String.format("%.2f",s.risk?.risk_score?:.5)}");Button({vm.calculateRisk(RiskAnswers())}){Text("محاسبه با پاسخ خنثی نمونه")}}}};item{Text("پیش‌بینی ماه آینده",style=MaterialTheme.typography.titleMedium)};items(s.forecast?.forecasts?:emptyList()){f->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(f.category);Text("پیش‌بینی: ${money(f.predicted_spending)}");Text("بودجه پیشنهادی: ${money(f.suggested_budget)} • ${f.model}")}}}}}
