package com.smartfin.assistant.data.api

import com.smartfin.assistant.data.model.*
import retrofit2.http.*
interface ApiService {
 @POST("api/auth/register") suspend fun register(@Body b:RegisterRequest):TokenResponse
 @POST("api/auth/login") suspend fun login(@Body b:LoginRequest):TokenResponse
 @GET("api/users/me") suspend fun me():UserDto
 @GET("api/transactions") suspend fun transactions(@Query("from_date") from:String?=null,@Query("to_date") to:String?=null):List<TransactionDto>
 @POST("api/transactions") suspend fun addTransaction(@Body b:TransactionDto):TransactionDto
 @PUT("api/transactions/{id}") suspend fun updateTransaction(@Path("id") id:Int,@Body b:TransactionDto):TransactionDto
 @DELETE("api/transactions/{id}") suspend fun deleteTransaction(@Path("id") id:Int)
 @GET("api/incomes") suspend fun incomes():List<IncomeDto>
 @POST("api/incomes") suspend fun addIncome(@Body b:IncomeDto):IncomeDto
 @PUT("api/incomes/{id}") suspend fun updateIncome(@Path("id") id:Int,@Body b:IncomeDto):IncomeDto
 @DELETE("api/incomes/{id}") suspend fun deleteIncome(@Path("id") id:Int)
 @GET("api/goals") suspend fun goals():List<GoalDto>
 @POST("api/goals") suspend fun addGoal(@Body b:GoalDto):GoalDto
 @PUT("api/goals/{id}") suspend fun updateGoal(@Path("id") id:Int,@Body b:GoalDto):GoalDto
 @DELETE("api/goals/{id}") suspend fun deleteGoal(@Path("id") id:Int)
 @GET("api/analysis/behavior") suspend fun behavior():BehaviorDto
 @GET("api/analysis/forecast") suspend fun forecast():ForecastDto
 @POST("api/risk-profile/calculate") suspend fun calculateRisk(@Body b:RiskAnswers):RiskDto
 @GET("api/risk-profile") suspend fun risk():RiskDto
 @GET("api/recommendations") suspend fun recommendations():List<RecommendationDto>
 @POST("api/chat") suspend fun chat(@Body b:ChatRequest):ChatResponse
 @GET("api/institutions") suspend fun institutions():List<InstitutionDto>
 @POST("api/investment/portfolio/suggest") suspend fun suggestPortfolio(@Body b:PortfolioSuggestRequest):PortfolioResponse
 @POST("api/investment/simulate") suspend fun simulateInvestment(@Body b:SimulationRequest):SimulationResponse
 @POST("api/investment/recommendation") suspend fun investmentRecommendation(@Body b:PortfolioSuggestRequest):InvestmentRecommendationResponse
}
