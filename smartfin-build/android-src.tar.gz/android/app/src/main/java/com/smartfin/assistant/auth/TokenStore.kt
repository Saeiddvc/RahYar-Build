package com.smartfin.assistant.auth
import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
private val Context.ds by preferencesDataStore("auth")
class TokenStore(private val context:Context){
 private val key=stringPreferencesKey("jwt")
 suspend fun get():String?=context.ds.data.first()[key]
 suspend fun set(v:String){context.ds.edit{it[key]=v}}
 suspend fun clear(){context.ds.edit{it.remove(key)}}
}
