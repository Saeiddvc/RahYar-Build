package com.smartfin.assistant.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.smartfin.assistant.ui.ChatViewModel
@Composable fun ChatScreen(vm:ChatViewModel){val s by vm.state.collectAsState();var text by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(12.dp)){Text("دستیار مالی",style=MaterialTheme.typography.headlineSmall);LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)){items(s.messages){m->Row(Modifier.fillMaxWidth(),horizontalArrangement=if(m.mine)Arrangement.End else Arrangement.Start){Surface(tonalElevation=2.dp,shape=MaterialTheme.shapes.medium){Text(m.text,Modifier.padding(12.dp).widthIn(max=300.dp))}}}};Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(text,{text=it},label={Text("سؤال شما")},modifier=Modifier.weight(1f));Button({val m=text;text="";vm.send(m)},enabled=!s.loading){Text("ارسال")}}}}
