package com.smartfin.assistant
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import com.smartfin.assistant.ui.*
import com.smartfin.assistant.ui.screens.*
import com.smartfin.assistant.ui.theme.SmartFinTheme
import org.koin.androidx.compose.koinViewModel
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{SmartFinTheme{Root()}}}}
data class NavItem(val route:String,val label:String,val icon:androidx.compose.ui.graphics.vector.ImageVector)
@Composable fun Root(auth:AuthViewModel=koinViewModel()){val a by auth.state.collectAsState();if(!a.loggedIn){AuthScreen(auth);return};val nav=rememberNavController();val finance:FinanceViewModel=koinViewModel();val chat:ChatViewModel=koinViewModel();val investment:InvestmentViewModel=koinViewModel();val items=listOf(NavItem("dashboard","خانه",Icons.Default.Home),NavItem("transactions","تراکنش",Icons.Default.ReceiptLong),NavItem("investment","سرمایه",Icons.Default.AccountBalance),NavItem("insights","تحلیل",Icons.Default.Insights),NavItem("chat","چت",Icons.Default.Chat));Scaffold(bottomBar={NavigationBar{val current=nav.currentBackStackEntryAsState().value?.destination?.route;items.forEach{i->NavigationBarItem(selected=current==i.route,onClick={nav.navigate(i.route){launchSingleTop=true;popUpTo("dashboard"){saveState=true};restoreState=true}},icon={Icon(i.icon,null)},label={Text(i.label)})}}}){pad->NavHost(nav,startDestination="dashboard",Modifier.padding(pad)){composable("dashboard"){DashboardScreen(finance,onGoals={nav.navigate("goals")},onIncomes={nav.navigate("incomes")},onSettings={nav.navigate("settings")})};composable("transactions"){TransactionsScreen(finance)};composable("goals"){GoalsScreen(finance)};composable("investment"){InvestmentHubScreen(investment)};composable("insights"){InsightsScreen(finance)};composable("chat"){ChatScreen(chat)};composable("incomes"){IncomesScreen(finance)};composable("settings"){SettingsScreen(auth)}}}}
