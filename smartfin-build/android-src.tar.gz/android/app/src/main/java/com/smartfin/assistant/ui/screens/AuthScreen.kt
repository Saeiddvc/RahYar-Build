package com.smartfin.assistant.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.smartfin.assistant.ui.AuthViewModel
import com.smartfin.assistant.ui.components.ErrorText
@Composable fun AuthScreen(vm:AuthViewModel){var register by remember{mutableStateOf(false)};var name by remember{mutableStateOf("")};var email by remember{mutableStateOf("")};var pass by remember{mutableStateOf("")};val s by vm.state.collectAsState();Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Card(Modifier.fillMaxWidth().padding(24.dp)){Column(Modifier.padding(24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("SmartFin AI",style=MaterialTheme.typography.headlineMedium);Text(if(register)"ایجاد حساب" else "ورود به دستیار مالی");if(register)OutlinedTextField(name,{name=it},label={Text("نام")},modifier=Modifier.fillMaxWidth());OutlinedTextField(email,{email=it},label={Text("ایمیل")},modifier=Modifier.fillMaxWidth());OutlinedTextField(pass,{pass=it},label={Text("رمز عبور")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth());ErrorText(s.error);Button(onClick={if(register)vm.register(name,email,pass) else vm.login(email,pass)},enabled=!s.loading,modifier=Modifier.fillMaxWidth()){Text(if(s.loading)"در حال اتصال..." else if(register)"ثبت‌نام" else "ورود")};TextButton({register=!register},Modifier.fillMaxWidth()){Text(if(register)"حساب دارم" else "ثبت‌نام")}}}}}
