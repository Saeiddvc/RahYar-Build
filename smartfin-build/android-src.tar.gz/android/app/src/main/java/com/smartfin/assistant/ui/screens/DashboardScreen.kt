package com.smartfin.assistant.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.smartfin.assistant.ui.FinanceViewModel
import com.smartfin.assistant.ui.components.*
@Composable fun DashboardScreen(vm:FinanceViewModel,onGoals:()->Unit={},onIncomes:()->Unit={},onSettings:()->Unit={}){val s by vm.state.collectAsState();LaunchedEffect(Unit){vm.refresh()};val income=s.incomes.sumOf{if(it.frequency=="weekly")it.amount*4.33 else it.amount};val expense=s.transactions.filter{runCatching{java.time.OffsetDateTime.parse(it.date)}.getOrNull()?.month==java.time.OffsetDateTime.now().month}.sumOf{it.amount};LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("سلام ${s.user?.name?:""}",style=MaterialTheme.typography.headlineSmall);ErrorText(s.error)};item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){StatCard("درآمد ماهانه",money(income),Modifier.weight(1f));StatCard("هزینه این ماه",money(expense),Modifier.weight(1f))}};item{StatCard("پس‌انداز تخمینی",money(income-expense),Modifier.fillMaxWidth())};item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onGoals,Modifier.weight(1f)){Text("اهداف")};OutlinedButton(onIncomes,Modifier.weight(1f)){Text("درآمد")};OutlinedButton(onSettings,Modifier.weight(1f)){Text("تنظیمات")}}};item{Text("ترکیب هزینه‌ها",style=MaterialTheme.typography.titleMedium);CategoryBars(s.behavior?.totals_by_category?:emptyMap())};item{Text("پیشنهادهای مهم",style=MaterialTheme.typography.titleMedium)};items(s.recommendations.take(4)){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(it.type,style=MaterialTheme.typography.labelMedium);Text(it.message)}}}}}
@Composable private fun CategoryBars(m:Map<String,Double>){if(m.isEmpty()){Text("هنوز داده کافی ثبت نشده است.");return};val max=m.values.maxOrNull()?:1.0;Column(verticalArrangement=Arrangement.spacedBy(8.dp)){m.entries.sortedByDescending{it.value}.take(6).forEach{e->Text("${e.key}: ${money(e.value)}");LinearProgressIndicator(progress={ (e.value/max).toFloat() },modifier=Modifier.fillMaxWidth())}}}
