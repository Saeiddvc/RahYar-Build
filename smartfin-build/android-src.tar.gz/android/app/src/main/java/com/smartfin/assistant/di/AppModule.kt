package com.smartfin.assistant.di
import com.smartfin.assistant.BuildConfig
import com.smartfin.assistant.auth.TokenStore
import com.smartfin.assistant.data.api.ApiService
import com.smartfin.assistant.data.repository.FinanceRepository
import com.smartfin.assistant.ui.AuthViewModel
import com.smartfin.assistant.ui.FinanceViewModel
import com.smartfin.assistant.ui.ChatViewModel
import com.smartfin.assistant.ui.InvestmentViewModel
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
val appModule= module {
 single { TokenStore(get()) }
 single { OkHttpClient.Builder().addInterceptor { chain -> val t=runBlocking{get<TokenStore>().get()}; val b=chain.request().newBuilder(); if(!t.isNullOrBlank()) b.header("Authorization","Bearer $t"); chain.proceed(b.build()) }.addInterceptor(HttpLoggingInterceptor().apply{level=HttpLoggingInterceptor.Level.BASIC}).build() }
 single { Retrofit.Builder().baseUrl(BuildConfig.API_BASE_URL).client(get()).addConverterFactory(GsonConverterFactory.create()).build().create(ApiService::class.java) }
 single { FinanceRepository(get(),get()) }
 viewModel { AuthViewModel(get()) }; viewModel { FinanceViewModel(get()) }; viewModel { ChatViewModel(get()) }; viewModel { InvestmentViewModel(get()) }
}
